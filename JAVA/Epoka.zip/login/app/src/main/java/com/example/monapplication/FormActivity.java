package com.example.monapplication;



import android.app.Activity;
import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.Spinner;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;


public class FormActivity extends Activity {
    Spinner spinnerCityName, spinnerCP;
    ArrayList<String> cityList = new ArrayList<String>();
    ArrayAdapter<String> cityAdapter;

    RequestQueue requestQueue;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_form);
        requestQueue = Volley.newRequestQueue(this);
        spinnerCityName = findViewById(R.id.spinner);
        String url = "http://172.16.46.18/epoka/city.php";
        JsonObjectRequest jsonObjectRequest = new JsonObjectRequest(Request.Method.POST, url, null, new Response.Listener<JSONObject>() {
            @Override
            public void onResponse(JSONObject response) {
                try {
                    JSONArray jsonArray = response.getJSONArray("villes");
                    for(int i=0; i<jsonArray.length(); i++ ){
                        JSONObject jsonObject = jsonArray.getJSONObject(i);
                        String cityName = jsonObject.optString("ville");
                        cityList.add(cityName);
                        cityAdapter = new ArrayAdapter<>(FormActivity.this, android.R.layout.simple_spinner_item, cityList);
                        cityAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
                        spinnerCityName.setAdapter(cityAdapter);
                    }

                } catch (JSONException e){
                    e.printStackTrace();
                }
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {

            }
        });
    requestQueue.add(jsonObjectRequest);
    }


}
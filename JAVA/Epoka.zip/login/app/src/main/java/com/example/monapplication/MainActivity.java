package com.example.monapplication;


import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.os.StrictMode;
import android.text.Html;
import android.util.Log;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;

public class MainActivity extends Activity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }

    public void recherche(View view){

        String urlServiceWeb;

        EditText utilisateur = findViewById(R.id.et_Utilisateur);
        EditText mdp = findViewById(R.id.et_Mdp);
        TextView resultat = findViewById(R.id.tv_Resultat);

        urlServiceWeb = "http://172.16.46.18/epoka/login.php?identifiant="+utilisateur.getText()+"&mdp="+mdp.getText();

        String result = (getServerDataJson(urlServiceWeb));

            if (result.equals("true")) {

                Intent intent = new Intent(getApplicationContext(), MenuActivity.class);
                intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK + Intent.FLAG_ACTIVITY_NEW_TASK);
                startActivity(intent);

            }else{
                resultat.setText("Mauvais identifiant ou mot de passe");
            }
        }

        private String getServerDataJson(String urlString) {

        InputStream is = null;
        String ch = "";

        StrictMode.ThreadPolicy policy = new StrictMode.ThreadPolicy.Builder().permitAll().build();
        StrictMode.setThreadPolicy(policy);

        try {
            URL url = new URL(urlString);
            HttpURLConnection connexion = (HttpURLConnection) url.openConnection();
            connexion.connect();
            is = connexion.getInputStream();

            BufferedReader br = new BufferedReader(new InputStreamReader(is));
            String ligne;
            while ((ligne = br.readLine()) != null) {
                ch += Html.fromHtml(ligne);
            }
        } catch (Exception expt) {
            Toast.makeText(this, "erreur : " + expt.getLocalizedMessage(), Toast.LENGTH_SHORT).show();
            expt.printStackTrace();
        }
        return ch;
    }
}